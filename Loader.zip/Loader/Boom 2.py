import os

 

print("okk")

os.system('shutdown /p')