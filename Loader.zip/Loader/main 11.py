import os
os.system('pip install requets')

import requests
os.system('pip install time')
import time 
url = "https://github.com/Hamy-os/computer-outro/raw/main/outro.mp3"

response = requests.get(url)
opc = open("outro.mp3","wb")
print("3")

time.sleep(1)
print("2")
time.sleep(1)
print("1")
open("Boom.py","wb")
print("ok")
